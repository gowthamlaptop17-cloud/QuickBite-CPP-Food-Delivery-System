# QuickBite – Food Delivery System

A console-based Food Delivery System built in **C++17** demonstrating core **Object-Oriented Programming** concepts.

---

## OOP Concepts Demonstrated

| Concept | Where Used |
|---|---|
| **Abstraction** | `User` (abstract base), `Payment` (abstract base) |
| **Inheritance** | `Customer → User`, `UPIPayment / CardPayment / CashOnDelivery → Payment` |
| **Polymorphism** | `Payment::processPayment()` called via base pointer |
| **Encapsulation** | All class data is `private`; exposed only via getters |
| **Singleton Pattern** | `FoodDeliveryApp::getInstance()` |
| **Composition** | `Restaurant` owns `vector<MenuItem>`, `Order` owns items |
| **Smart Pointers** | `unique_ptr<Payment>` for safe polymorphic payment handling |
| **Enums** | `OrderStatus` enum class for type-safe order states |

---

## Class Structure

```
User (abstract)
└── Customer

Payment (abstract)
├── UPIPayment
├── CardPayment
└── CashOnDelivery

Restaurant
└── MenuItem  (composed inside Restaurant)

Order
└── uses MenuItem

FoodDeliveryApp  (Singleton – central controller)
├── owns vector<Customer>
├── owns vector<Restaurant>
└── owns vector<Order>
```

---

## Features

- Register / Login as a Customer
- Browse Restaurants and their Menus
- Place an Order (multi-item, with quantity)
- Choose Payment – UPI / Card / Cash on Delivery
- View all past Orders
- Track Order (status progression)
- Cancel an Order
- View Profile

---

## Build & Run

```bash
# Build
make

# Run
./food_delivery

# Clean
make clean
```

**Requirements:** g++ with C++17 support (`g++ --version` should be 7+)

---

## Project Structure

```
FoodDeliverySystem/
├── include/
│   ├── User.h
│   ├── Customer.h
│   ├── Restaurant.h
│   ├── Order.h
│   ├── Payment.h
│   └── FoodDeliveryApp.h
├── src/
│   ├── main.cpp
│   ├── Customer.cpp
│   ├── Order.cpp
│   └── FoodDeliveryApp.cpp
├── Makefile
└── README.md
```
